import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import type { Metadata } from "next"
import Script from "next/script"
import ThemeToggle from "@/components/theme-toggle"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Image Compression Tool",
  description: "Compress and optimize your images for the web",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#ffffff" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className={inter.className}>
        <div className="fixed right-4 top-4 z-50">
          <ThemeToggle />
        </div>
        {children}

        {/* Google AdSense Script */}
        <Script
          id="google-adsense"
          async
          strategy="afterInteractive"
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_ADSENSE_ID"
          crossOrigin="anonymous"
        />

        {/* Script to initialize ads */}
        <Script id="initialize-ads" strategy="afterInteractive">
          {`
            (function() {
              try {
                if (typeof window !== 'undefined' && window.adsbygoogle) {
                  window.adsbygoogle = window.adsbygoogle || [];
                  window.adsbygoogle.push({});
                }
              } catch (e) {
                console.error('AdSense error:', e);
              }
            })();
          `}
        </Script>
      </body>
    </html>
  )
}



import './globals.css'