import ImageCompressor from "@/components/image-compressor"
import type { Metadata } from "next"
import { ImageIcon } from "lucide-react"

export const metadata: Metadata = {
  title: "Image Compression Tool | Optimize Your Images",
  description:
    "Free online tool to compress and optimize your images. Reduce file size while maintaining quality for faster websites.",
  keywords: "image compression, image optimizer, reduce image size, optimize images, image compressor",
}

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 px-4">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-12 text-center">
          <div className="relative mb-6 inline-block">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 opacity-75 blur"></div>
            <div className="relative">
              <div className="inline-flex items-center justify-center rounded-full bg-white p-2 dark:bg-gray-900">
                <ImageIcon className="h-8 w-8 text-purple-500" />
              </div>
            </div>
          </div>
          <h1 className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-4xl font-extrabold text-transparent md:text-5xl">
            Image Compression Tool
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-gray-600 dark:text-gray-300">
            Optimize your images for the web. Reduce file size while maintaining quality for faster websites and better
            user experience.
          </p>
        </header>

        {/* Ad Space - Top Banner */}
        <div className="mb-8 w-full overflow-hidden rounded-xl bg-white p-4 text-center shadow-md dark:bg-gray-800">
          <div className="mb-2 text-sm text-gray-500 dark:text-gray-400">Advertisement</div>
          <div id="ad-banner-top" className="flex min-h-[90px] items-center justify-center">
            <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Ad Space - Sidebar */}
          <div className="hidden h-fit rounded-xl bg-white p-4 shadow-md dark:bg-gray-800 lg:block">
            <div className="mb-2 text-sm text-gray-500 dark:text-gray-400">Advertisement</div>
            <div id="ad-sidebar" className="flex min-h-[600px] items-center justify-center">
              <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <ImageCompressor />
          </div>
        </div>

        {/* Ad Space - Bottom Banner */}
        <div className="mt-8 w-full overflow-hidden rounded-xl bg-white p-4 text-center shadow-md dark:bg-gray-800">
          <div className="mb-2 text-sm text-gray-500 dark:text-gray-400">Advertisement</div>
          <div id="ad-banner-bottom" className="flex min-h-[90px] items-center justify-center">
            <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
          </div>
        </div>

        <footer className="mt-12 text-center text-sm text-gray-600 dark:text-gray-400">
          <p>© {new Date().getFullYear()} Image Compression Tool. All rights reserved.</p>
          <div className="mt-2 flex justify-center space-x-4">
            <a href="#" className="hover:text-purple-500">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-purple-500">
              Terms of Service
            </a>
            <a href="#" className="hover:text-purple-500">
              Contact
            </a>
          </div>
        </footer>
      </div>
    </main>
  )
}

