"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, Download, ImageIcon, Trash2, RefreshCw } from "lucide-react"
import imageCompression from "browser-image-compression"

export default function ImageCompressor() {
  const [originalImage, setOriginalImage] = useState<File | null>(null)
  const [compressedImage, setCompressedImage] = useState<File | null>(null)
  const [originalPreview, setOriginalPreview] = useState<string>("")
  const [compressedPreview, setCompressedPreview] = useState<string>("")
  const [originalSize, setOriginalSize] = useState<string>("")
  const [compressedSize, setCompressedSize] = useState<string>("")
  const [compressionLevel, setCompressionLevel] = useState<number>(80)
  const [isCompressing, setIsCompressing] = useState<boolean>(false)
  const [compressionRate, setCompressionRate] = useState<number>(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setOriginalImage(file)
    setOriginalSize(formatFileSize(file.size))
    setCompressedImage(null)
    setCompressedPreview("")
    setCompressedSize("")
    setCompressionRate(0)

    const reader = new FileReader()
    reader.onload = () => {
      setOriginalPreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    const file = e.dataTransfer.files?.[0]
    if (!file) return

    setOriginalImage(file)
    setOriginalSize(formatFileSize(file.size))
    setCompressedImage(null)
    setCompressedPreview("")
    setCompressedSize("")
    setCompressionRate(0)

    const reader = new FileReader()
    reader.onload = () => {
      setOriginalPreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
  }

  const handleCompress = useCallback(async () => {
    if (!originalImage) return

    setIsCompressing(true)

    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true,
        quality: compressionLevel / 100,
      }

      const compressedFile = await imageCompression(originalImage, options)
      setCompressedImage(compressedFile)
      setCompressedSize(formatFileSize(compressedFile.size))

      const reader = new FileReader()
      reader.onload = () => {
        setCompressedPreview(reader.result as string)
      }
      reader.readAsDataURL(compressedFile)

      // Calculate compression rate
      const rate = 100 - (compressedFile.size / originalImage.size) * 100
      setCompressionRate(Math.round(rate))
    } catch (error) {
      console.error("Error compressing image:", error)
    } finally {
      setIsCompressing(false)
    }
  }, [compressionLevel, originalImage])

  const handleDownload = () => {
    if (!compressedImage) return

    const link = document.createElement("a")
    link.href = compressedPreview
    link.download = `compressed-${compressedImage.name}`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleReset = () => {
    setOriginalImage(null)
    setCompressedImage(null)
    setOriginalPreview("")
    setCompressedPreview("")
    setOriginalSize("")
    setCompressedSize("")
    setCompressionRate(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  useEffect(() => {
    if (originalImage && compressionLevel) {
      handleCompress()
    }
  }, [compressionLevel, originalImage, handleCompress])

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border-0 shadow-lg">
        <CardContent className="p-6">
          <div
            className="group relative cursor-pointer overflow-hidden rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 p-8 text-center transition-all hover:border-purple-400 dark:border-gray-600 dark:bg-gray-800/50 dark:hover:border-purple-400"
            onClick={() => fileInputRef.current?.click()}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <div className="absolute inset-0 -z-10 bg-gradient-to-r from-pink-200 via-purple-200 to-blue-200 opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-30 dark:from-pink-800 dark:via-purple-800 dark:to-blue-800"></div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
              aria-label="Upload image"
            />
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="rounded-full bg-purple-100 p-4 text-purple-500 transition-transform duration-300 group-hover:scale-110 dark:bg-purple-900/30">
                <Upload className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Upload an image</h3>
              <p className="text-gray-500 dark:text-gray-400">Drag and drop or click to select</p>
              <p className="text-xs text-gray-400 dark:text-gray-500">Supports: JPG, PNG, WebP (Max: 10MB)</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {originalImage && (
        <>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Compression Level</h3>
                  <span className="rounded-full bg-purple-100 px-3 py-1 text-sm font-medium text-purple-600 dark:bg-purple-900/30 dark:text-purple-300">
                    {compressionLevel}%
                  </span>
                </div>
                <Slider
                  value={[compressionLevel]}
                  onValueChange={(value) => setCompressionLevel(value[0])}
                  min={1}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>Higher Quality</span>
                  <span>Smaller Size</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Card className="overflow-hidden border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="flex items-center text-lg font-medium">
                      <div className="mr-2 rounded-full bg-gray-100 p-1 dark:bg-gray-800">
                        <ImageIcon className="h-5 w-5 text-gray-500" />
                      </div>
                      Original
                    </h3>
                    <span className="rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                      {originalSize}
                    </span>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                    {originalPreview ? (
                      <img
                        src={originalPreview || "/placeholder.svg"}
                        alt="Original image preview"
                        className="h-full w-full object-contain"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <span className="text-gray-400 dark:text-gray-500">No image</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="flex items-center text-lg font-medium">
                      <div className="mr-2 rounded-full bg-purple-100 p-1 dark:bg-purple-900/30">
                        <ImageIcon className="h-5 w-5 text-purple-500" />
                      </div>
                      Compressed
                    </h3>
                    <div className="flex items-center space-x-2">
                      {compressionRate > 0 && (
                        <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-medium text-green-600 dark:bg-green-900/30 dark:text-green-300">
                          -{compressionRate}%
                        </span>
                      )}
                      <span className="rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                        {compressedSize}
                      </span>
                    </div>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                    {isCompressing ? (
                      <div className="flex h-full items-center justify-center">
                        <div className="relative">
                          <div className="absolute -inset-4 rounded-full bg-purple-500 opacity-30 blur-md animate-pulse"></div>
                          <RefreshCw className="relative h-8 w-8 animate-spin text-purple-500" />
                        </div>
                      </div>
                    ) : compressedPreview ? (
                      <img
                        src={compressedPreview || "/placeholder.svg"}
                        alt="Compressed image preview"
                        className="h-full w-full object-contain"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <span className="text-gray-400 dark:text-gray-500">Processing...</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Button
              variant="outline"
              onClick={handleReset}
              className="flex items-center border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Reset
            </Button>
            <Button
              onClick={handleDownload}
              disabled={!compressedImage || isCompressing}
              className="flex items-center bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white hover:opacity-90"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Compressed Image
            </Button>
          </div>
        </>
      )}
    </div>
  )
}

